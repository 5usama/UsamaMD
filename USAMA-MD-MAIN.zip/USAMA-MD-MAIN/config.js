const fs = require('fs');
if (fs.existsSync('config.env')) require('dotenv').config({ path: './config.env' });

function convertToBool(text, fault = 'true') {
    return text === fault ? true : false;
}
module.exports = {
SESSION_ID: process.env.SESSION_ID || "eyJub2lzZUtleSI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoid0Z2S1Y4QWdwUHhIT3VTcjYvMXNOTit6K29zeUFlYk0xQ1ZLN1lBb0ZVQT0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiMy95VVVWNW1NUlkzTXBqSDYxcHM4VWNBc3U1MVhNSXA0NThwWW9Idy93WT0ifX0sInBhaXJpbmdFcGhlbWVyYWxLZXlQYWlyIjp7InByaXZhdGUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiIrRVRIYktwRHIwN1QzOXhRVVUrNDJyWllMZnFGeUZUZ0w4M3hkbzdXTm1ZPSJ9LCJwdWJsaWMiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJEQTduTlE0QmVOY1QramVjNngweFhJN3pjUmZGakE1WkY0cGwyemRFV2xNPSJ9fSwic2lnbmVkSWRlbnRpdHlLZXkiOnsicHJpdmF0ZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IldLSUxHNXh1YnRqRVVLcVhwUmljR0toKzN1NDUyWTdkanlmR215elcza2s9In0sInB1YmxpYyI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IjZiZ2xpQ1dkMThLeFRjN2hhOUYyeWlUVVBSakJyMkNPeUNpWE04ZG83V1U9In19LCJzaWduZWRQcmVLZXkiOnsia2V5UGFpciI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiV0Y0dUFhL3pJdkhyYmNzdlVZNXFhdDVobEdqM2w3S0d6TFlwZjh1dWlYWT0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoicE4rb0k1QXcxbGUvVzdDZENpdWJETzdYSEd6ck1LaW0vMGIzWHQvRFVWST0ifX0sInNpZ25hdHVyZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6Ijl3RkZYNWJtVGQ4VEx2VUl1UzJqcWdMSU1uK3FHUzZHY0N2cVJLYSs3K3c0RjkrWmthc1BjZ0F4bjJ5L0I3bzZsM0FyYlRXV3RETW9tay80TGRqc2hRPT0ifSwia2V5SWQiOjF9LCJyZWdpc3RyYXRpb25JZCI6MTkzLCJhZHZTZWNyZXRLZXkiOiJsRFB5MG12ajVDSE1mZkVON3RaVlBkYXBOeThxS0NtT3pDZW1CU1cyZG9VPSIsInByb2Nlc3NlZEhpc3RvcnlNZXNzYWdlcyI6W10sIm5leHRQcmVLZXlJZCI6MzEsImZpcnN0VW51cGxvYWRlZFByZUtleUlkIjozMSwiYWNjb3VudFN5bmNDb3VudGVyIjowLCJhY2NvdW50U2V0dGluZ3MiOnsidW5hcmNoaXZlQ2hhdHMiOmZhbHNlfSwiZGV2aWNlSWQiOiJBQXJsaWRNalJtYVV2eUMwQ2IxbVpBIiwicGhvbmVJZCI6IjVhMTE1NzQ1LTU5N2EtNDFhYS04MjE2LTdjMmNiOWQxN2I2NCIsImlkZW50aXR5SWQiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJXL3Q2VDdKQUt5RnBrY2xNMFFBSHJ3Mk1lNnc9In0sInJlZ2lzdGVyZWQiOnRydWUsImJhY2t1cFRva2VuIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiYUVaRVMxT0oyRTlma0NyTUVFajYrRlBYcWtJPSJ9LCJyZWdpc3RyYXRpb24iOnt9LCJwYWlyaW5nQ29kZSI6IjhGWERBRTU4IiwibWUiOnsiaWQiOiI5MjMyMzk2MDE1ODU6MjdAcy53aGF0c2FwcC5uZXQifSwiYWNjb3VudCI6eyJkZXRhaWxzIjoiQ0o3WTF1Z0VFSytQOXI0R0dBWWdBQ2dBIiwiYWNjb3VudFNpZ25hdHVyZUtleSI6IkpTc1oyajF2TVVXcGJzVVhnYVp2c0Mwc2VVVUFBTVNCaXFYYWxrTEI5Rnc9IiwiYWNjb3VudFNpZ25hdHVyZSI6ImdLY3gxMERLaUpHRFZpczhKN2ExL0Z5UEdlcFRjdWZwc2s5eDlTNG9MVWU4YWQwL2Qxc1NXOVJUWjZYQWZicVc4dVp5UTNlSUZhN0txby8yNlo4aEJ3PT0iLCJkZXZpY2VTaWduYXR1cmUiOiI5aWFlUnRMS1pId3AxRHA5TWtCQ282N0E2N0JMTzFRVlFnVkhSZW1KSzhMQSszZURUVjBxK3gxUlp1cy8yRTRrWFAwRmh5YURaWmUvSTRGdjVtK3Vndz09In0sInNpZ25hbElkZW50aXRpZXMiOlt7ImlkZW50aWZpZXIiOnsibmFtZSI6IjkyMzIzOTYwMTU4NToyN0BzLndoYXRzYXBwLm5ldCIsImRldmljZUlkIjowfSwiaWRlbnRpZmllcktleSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IkJTVXJHZG85YnpGRnFXN0ZGNEdtYjdBdExIbEZBQURFZ1lxbDJwWkN3ZlJjIn19XSwicGxhdGZvcm0iOiJhbmRyb2lkIiwibGFzdEFjY291bnRTeW5jVGltZXN0YW1wIjoxNzQyNTcxNDU0LCJteUFwcFN0YXRlS2V5SWQiOiJBQUFBQUM5WCJ9",

AUTO_STATUS_SEEN: process.env.AUTO_STATUS_SEEN || "true",
// make true or false status auto seen
AUTO_STATUS_REPLY: process.env.AUTO_STATUS_REPLY || "false",
// make true if you want auto reply on status 
AUTO_STATUS_REACT: process.env.AUTO_STATUS_REACT || "true",
// make true if you want auto reply on status 
AUTO_STATUS_MSG: process.env.AUTO_STATUS_MSG || "*SEEN YOUR STATUS BY USAMA-MD 🤍*",
// set the auto reply massage on status reply  
PREFIX: process.env.PREFIX || ".",
// add your prifix for bot   
BOT_NAME: process.env.BOT_NAME || "USAMA-MD",
// add bot namw here for menu
STICKER_NAME: process.env.STICKER_NAME || "USAMA-MD",
// type sticker pack name 
CUSTOM_REACT: process.env.CUSTOM_REACT || "false",
// make this true for custum emoji react    
CUSTOM_REACT_EMOJIS: process.env.CUSTOM_REACT_EMOJIS || "💝,💖,💗,❤️‍🩹,❤️,🧡,💛,💚,💙,💜,🤎,🖤,🤍",
// chose custom react emojis by yourself 
DELETE_LINKS: process.env.DELETE_LINKS || "false",
// automatic delete links witho remove member 
OWNER_NUMBER: process.env.OWNER_NUMBER || "923239601585",
// add your bot owner number
OWNER_NAME: process.env.OWNER_NAME || "𝐔͢𝐒𝐀𝐌͢𝐀 𝐃͢𝐇̾𝐔͢𝐃𝐃𝐈",
// add bot owner name
DESCRIPTION: process.env.DESCRIPTION || "*𝐁͜𝐘͢ 𝐔͢𝐒𝐀𝐌͢𝐀 𝐌͢𝐃͢*",
// add bot owner name    
ALIVE_IMG: process.env.ALIVE_IMG || "https://files.catbox.moe/149k8x.jpg",
// add img for alive msg
LIVE_MSG: process.env.LIVE_MSG || "_MEIN HAMESHA YAHAA HI HU_ *USAMA-MD*⚡",
// add alive msg here 
READ_MESSAGE: process.env.READ_MESSAGE || "false",
// Turn true or false for automatic read msgs
AUTO_REACT: process.env.AUTO_REACT || "false",
// make this true or false for auto react on all msgs
ANTI_BAD: process.env.ANTI_BAD || "false",
// false or true for anti bad words  
MODE: process.env.MODE || "public",
// make bot public-private-inbox-group 
ANTI_LINK: process.env.ANTI_LINK || "true",
// make anti link true,false for groups 
AUTO_VOICE: process.env.AUTO_VOICE || "false",
// make true for send automatic voices
AUTO_STICKER: process.env.AUTO_STICKER || "false",
// make true for automatic stickers 
AUTO_REPLY: process.env.AUTO_REPLY || "false",
// make true or false automatic text reply 
ALWAYS_ONLINE: process.env.ALWAYS_ONLINE || "false",
// maks true for always online 
PUBLIC_MODE: process.env.PUBLIC_MODE || "true",
// make false if want private mod
AUTO_TYPING: process.env.AUTO_TYPING || "false",
// true for automatic show typing   
READ_CMD: process.env.READ_CMD || "false",
// true if want mark commands as read 
DEV: process.env.DEV || "923239601585",
//replace with your whatsapp number        
ANTI_VV: process.env.ANTI_VV || "true",
// true for anti once view 
ANTI_DEL_PATH: process.env.ANTI_DEL_PATH || "log", 
// change it to 'same' if you want to resend deleted message in same chat 
AUTO_RECORDING: process.env.AUTO_RECORDING || "false"
// make it true for auto recoding 
};
