const config = require('../config')
const { cmd, commands } = require('../command');
const os = require("os")
const {runtime} = require('../lib/functions')
const axios = require('axios')

cmd({
    pattern: "menu",
    alias: ["allmenu","fullmenu"],use: '.menu2',
    desc: "menu the bot",
    category: "menu",
    react: "⚡",
    filename: __filename
}, 
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        let dec = `
╭━━━〔 *${config.BOT_NAME}* 〕━━━┈⊷  
┃
┃ 👑 Owner : *${config.OWNER_NAME}*  
┃
┃ 🆕 Version : *1.0.0*  
╰━━━━━━━━━━━━━━━┈⊷  

╭━━〔 *Download Menu* 〕━━┈⊷  
┃ 📥 fb
┃ 📥 mediafire  
┃ 🎶 tiktok  
┃ 📦 apk  
┃ 🖼️ img  
┃ 🎶 play  
┃ 🎞️ video  
┃ 🔊 audio  
┃ 🎬 ytmp4  
┃ 🎧 ytmp3  
┃ 🎤 song  
┃ 📂 gdrive    
╰━━━━━━━━━━━━━━━┈⊷  

╭━━〔 *Group Menu* 〕━━┈⊷  
┃ 🔗 grouplink  
┃ 🚪 kick  
┃ 🏆 promote  
┃ 👥 demote  
┃ 📢 tagall  
┃ 🛑 mute  
┃ 🔓 unlockgc  
┃ 🔒 lockgc  
┃ ✉️ setwelcome  
┃ 🎭 setgoodbye  
┃ 🏠 ginfo  
┃ 🔄 updategname  
╰━━━━━━━━━━━━━━━┈⊷  

╭━━〔 *Convert Menu* 〕━━┈⊷  
┃ 🔤 emojimix  
┃ 🔈 tts  
┃ 🎵 tomp3  
┃ 📝 trt  
┃ 🔗 tinyurl  
┃ 🧮 calculate  
╰━━━━━━━━━━━━━━━┈⊷  

╭━━〔 *AI Menu* 〕━━┈⊷  
┃ 🤖 gpt4  
┃ 🤯 meta  
┃ 💡 blackbox  
┃ 🎭 imagine  
┃ 🔥 dj  
╰━━━━━━━━━━━━━━━┈⊷  

╭━━〔 *Owner Menu* 〕━━┈⊷  
┃ 👑 owner  
┃ ⚠️ shutdown  
┃ 🔓 unblock  
┃ 🚷 block  
┃ 🏆 fullpp  
╰━━━━━━━━━━━━━━━┈⊷  

╭━━〔 *Other Menu* 〕━━┈⊷  
┃ ⏰ timenow  
┃ 📅 date  
┃ 🎲 flip  
┃ 🎯 roll  
┃ 🔢 count  
┃ 📚 wikipedia  
┃ 📰 news  
┃ 🎥 movie  
┃ 🌦️ weather  
┃ 🔐 gpass  
┃ 🕵️ githubstalk  
┃ 🔎 yts  
╰━━━━━━━━━━━━━━━┈⊷  

⚡ *USAMA-MD is Online!* ⚡  
> ${config.DESCRIPTION}`;

        await conn.sendMessage(
            from,
            {
                image: { url: `https://files.catbox.moe/pgrzef.jpg` },
                caption: dec,
                contextInfo: {
                    mentionedJid: [m.sender],
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363359467682362@newsletter',
                        newsletterName: 'UsamaDhuddi',
                        serverMessageId: 143
                    }
                }
            },
            { quoted: mek }
        );

        // Send audio
        await conn.sendMessage(from, {
            audio: { url: 'https://github.com/JawadYTX/KHAN-DATA/raw/refs/heads/main/autovoice/menunew.m4a' },
            mimetype: 'audio/mp4',
            ptt: true
        }, { quoted: mek });
        
    } catch (e) {
        console.log(e);
        reply(`${e}`);
    }
});
